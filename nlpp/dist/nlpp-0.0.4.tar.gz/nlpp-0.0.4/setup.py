from setuptools import setup, find_packages

VERSION = '0.0.4'
DESCRIPTION = ''
LONG_DESCRIPTION = ''

# Setting up
setup(
    name="nlpp",
    version=VERSION,
    author="Adi_baba",
    author_email="<aditubecreations@gmail.com>",
    description=DESCRIPTION,
    keywords=[],
    include_package_data=True,
    packages=['nlpp'],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: Unix",
        "Operating System :: MacOS :: MacOS X",
        "Operating System :: Microsoft :: Windows",
    ]
)

